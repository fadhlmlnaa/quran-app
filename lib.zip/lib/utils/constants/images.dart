class Images{
  Images._();
  static Images get = Images._();

  String loIntro = 'assets/lottie/intro-animate.json';
}